function showhide(){
	if(document.getElementById("relatedlinks").style.display=='none')
	{
		document.getElementById("relatedlinks").style.display='block';
	}
	else
	{
		document.getElementById("relatedlinks").style.display='none';	
	}
}

function say_hello(){
  var name = document.getElementById("name").value;
  document.getElementById("welcome").innerHTML = "<h3>Welcome to my page " + name + "</h3>";
  if (name.length < 1) {
    document.getElementById("welcome").innerHTML = "";
  }
}

function rndm_colour(){
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color
}

function change_background(){
  color = rndm_colour();
  document.getElementById("body").style.backgroundColor = color;
}

//quiz validation

function validatename(){
	var name=document.getElementById("name").value;
	if(name=="")
	{
		alert("please enter the name");
		return false;
	}
	else{
		return true;
	}
}

function validateradio(){
	var rad=document.forms.quiz.elements.q1.value;
	if(rad==="")
	{
		alert("Please select anyone option in question1");
		return false;
	}
	else{
		return true;
	}
}

function validatefillthespace(){
	var space1=document.forms.quiz.elements.q2.value;
	var space2=document.forms.quiz.elements.q3.value;
	if(space1==="" && space2===""){
		alert("Type your answers in question2");
		return false;
	}
	else if(space1==="" || space2===""){
		alert("Some spaces in question2 need to be filled");
		return false;
	}
	else{
		return true;
	}
}

function validatenumber(){
	var num=document.forms.quiz.elements.q4.value;
	if(num.length== 0){
		alert("Select the appropriate number in question3");
		return false;
	}
	else{
		return true;
	}
}

function validatequiz(){
	if(validatename() && validateradio() && validatefillthespace() && validatenumber()){
		return true;
	}
	else{
		return false;
	}
}

//checking the answers for quiz

function submitquiz() {
  Quiz = document.forms.quiz.elements;
  var score = 0;
  if (validatequiz()) 
  {
    userAnswers = [Quiz.q1.value, Quiz.q2.value, Quiz.q3.value, Quiz.q4.value];
    actualAnswers = ["op2", "sars", "t", 12];
    for (var i = 0; i < actualAnswers.length; i++) 
	{
      if (userAnswers[i] == actualAnswers[i]) 
	  {
        score += 2.5;
      }
    }
    alert('your score was...'+score);
  }
}
